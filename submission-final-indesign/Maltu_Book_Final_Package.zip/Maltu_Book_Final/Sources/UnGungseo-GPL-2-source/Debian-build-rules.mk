#!/usr/bin/make -f
#export DH_VERBOSE=1

%:
	dh $@

override_dh_install:
	dh_install
	# Fix wrong name
	fontforge -script $(CURDIR)/debian/set-fontname.pe \
	  $(CURDIR)/debian/fonts-unfonts-core/usr/share/fonts/truetype/unfonts-core/UnDinaruLight.ttf \
	  "UnDinaru-Light"
	# Clear OS/2 fsType bits which are incorrectly set
	for F in $(CURDIR)/debian/fonts-unfonts-core/usr/share/fonts/truetype/unfonts-core/*.ttf; do \
	  fontforge -script $(CURDIR)/debian/clear-fstype.pe $$F; \
	done
