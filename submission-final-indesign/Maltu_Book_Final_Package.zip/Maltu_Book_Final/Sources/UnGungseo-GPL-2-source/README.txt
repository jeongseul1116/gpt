UnGungseo (은 궁서) source and license companion
================================================

This directory accompanies the unchanged UnGungseo.ttf used in the project.
The font is licensed under the GNU General Public License, version 2 (GPL-2),
as recorded by Debian. See GPL-2.txt and Debian-copyright.txt. This font does
not use the SIL Open Font License used by several other fonts in the package.

Copyright notices:
- 1998-2008, Koaunghi Un
- 2003, Park, Won-kyu
- 2003, Jungshik Shin
The full Debian copyright file also covers Debian packaging and identifies
the Debian metainfo file as CC0-1.0; that license text is supplied separately.

Corresponding published source
------------------------------
The three fonts-unfonts-core_* files are the complete Debian source package
for version 1:1.0.2-080608-23, downloaded on 2026-11-03 from:
https://deb.debian.org/debian/pool/main/f/fonts-unfonts-core/

- fonts-unfonts-core_1.0.2-080608.orig.tar.xz: upstream originals and notices
- fonts-unfonts-core_1.0.2-080608-23.debian.tar.xz: Debian packaging/build scripts
- fonts-unfonts-core_1.0.2-080608-23.dsc: signed source-package metadata

The two archive SHA-256 digests were checked against the .dsc. The OpenPGP
signature itself has not been independently verified against a signing key.
The .dsc is preserved as obtained over HTTPS from Debian.

The upstream archive supplies TrueType files as its editable font originals,
including UnGungseo.ttf, plus README and COPYING. It contains no .sfd files.
Debian's build uses FontForge to regenerate each original TTF after clearing
incorrect OS/2 fsType bits. Both the original TTF and all Debian build scripts
are retained in the source archives. The small extracted files in this folder
are convenient copies; the archives are the complete published source package.

Relationship to the delivered font
----------------------------------
The delivered font is extracted unchanged from the Debian binary package
fonts-unfonts-core, version 1:1.0.2-080608-23 (architecture all). It is not
byte-identical to the upstream TTF because Debian regenerates it with FontForge.
The font family, version (1.02), glyph count (19,034), copyright/license name
records, and Unicode character mapping agree between both forms. The upstream
fsType is 12; the Debian font's fsType is 0, as required by its build script.

SHA-256 of delivered UnGungseo.ttf:
7d1593ed524c1a4222191e4dea6e3d823598eacc73d8a47247748a55283955ff

SHA-256 of upstream UnGungseo.ttf inside orig.tar.xz:
9532dfd4d75699e9aae10b85dd3dcd3e49177a17a8affcd3f749024e1d2a4293

Working with the source
-----------------------
On Debian or a comparable development system, install dpkg-dev, debhelper
(compatibility level 14), and FontForge as identified by the source package's
Build-Depends, then extract using:

  dpkg-source -x fonts-unfonts-core_1.0.2-080608-23.dsc

The source includes debian/rules, debian/clear-fstype.pe and all other packaging
files needed to perform the Debian font processing. FontForge can open and
edit the original TTF directly. Rebuilding with a different FontForge version
or timestamps can produce different binary bytes.

If redistributing the font, keep its notices, GPL-2.txt, and this published
source companion available together. Consult GPL-2.txt for the actual terms.
