-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: fonts-unfonts-core
Binary: fonts-unfonts-core
Architecture: all
Version: 1:1.0.2-080608-23
Maintainer: Debian Fonts Task Force <debian-fonts@lists.debian.org>
Uploaders: Changwoo Ryu <cwryu@debian.org>, Hideki Yamane <henrich@debian.org>
Homepage: http://kldp.net/unfonts/
Standards-Version: 4.7.4
Vcs-Browser: https://salsa.debian.org/fonts-team/fonts-unfonts-core
Vcs-Git: https://salsa.debian.org/fonts-team/fonts-unfonts-core.git
Testsuite: autopkgtest
Testsuite-Triggers: fontconfig
Build-Depends: debhelper-compat (= 14), fontforge | fontforge-nox
Package-List:
 fonts-unfonts-core deb fonts optional arch=all
Checksums-Sha1:
 5cf408f7c6710179b49cd719204397061bc704d3 14988620 fonts-unfonts-core_1.0.2-080608.orig.tar.xz
 9d49c22841dc9c89bceda6af9cbea2d9bad78f71 6636 fonts-unfonts-core_1.0.2-080608-23.debian.tar.xz
Checksums-Sha256:
 14abb309f9d979cc20212fabfbd7f50b55c42183985ae507390c7461ce0b307c 14988620 fonts-unfonts-core_1.0.2-080608.orig.tar.xz
 97b018bad9af4440ae527af5b598549cf8869d643c5c7b797bbc213a7a658248 6636 fonts-unfonts-core_1.0.2-080608-23.debian.tar.xz
Files:
 8ca6e769d98b5af4a11228929da8bb99 14988620 fonts-unfonts-core_1.0.2-080608.orig.tar.xz
 931a43600d659dfa338dfba8bf4a6b4e 6636 fonts-unfonts-core_1.0.2-080608-23.debian.tar.xz
Dgit: 8316649b39cdcfc8845b6fe529f6bbddb1dcc7a2 debian archive/debian/1%1.0.2-080608-23 https://git.dgit.debian.org/fonts-unfonts-core
Git-Tag-Info: tag=44435b62e759c160298ba759851ddf459d300439 fp=a27cbeba35256865380e0cc9ec1879d076d8ab48
Git-Tag-Tagger: Changwoo Ryu <cwryu@debian.org>

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEN02M5NuW6cvUwJcqYG0ITkaDwHkFAmrBR5IACgkQYG0ITkaD
wHns5A//ThMndVKyo5JLys3SWYNRY/yg1ly1HbVDDUChCKc6jei54xOp1Pt7I5Bi
vZDCvVUApbq3oSZ2AC95OoLHp8mLK5WbnTgk+LfsM/vSxrJ03xkPAZYCF2R5i2k9
oiSeMsGbHYMlzYbmhxQpljbk1/w4Wi8iNti+AQ0uU2wWIMJGeh4vHTTqYshkfUeg
xCBZbQBUKYx8Zwuzm3XRLZCzT3KT81buwHefKUgP3uAsCrk6VirEjzbKcLdPSYKm
kFAq6uWr3wPTPWc4llMKtIU4DIbAurlbJao8iC2yot06XTozxGdVMbQOPCn/Fihr
E6HcxgjVGPwPcN9K7nbMCEpx1uIXzhYsLiLbhkQ6CgOGA+DaLhGziOmRykAzWgdo
00794adexjZgkRsN9MuQ4fQMgSSMnRnWAIs6hf/pbEx72DBePQpCsVTU761jvXAI
GRdoMFpqt/KSZb6hml+SbcM9NXxt3KYEyREi/Gx3MBygw4CLEjB9nthctPnDMAdt
DR8r9yXdGpAOk0MOsKprGH07HPSRjx61j7703Rg7EBstovJl/yqjeITMcXoW4KCy
Qfe5ENoncIV+GCdT/G0ftW/A9HJt6S9yFzdU13WvDUx9Ra25o8CQCwoxn9DFLkEk
2g6gr3E9FpxetDcysqP/Iax6LrFR5P0jxJmsDRCh8oLnC1Hv7rk=
=NB2z
-----END PGP SIGNATURE-----
