UnGungseo GPL-2 corresponding source is included with the same unmodified binary as the original source font package. Other font licenses are in Licenses.
